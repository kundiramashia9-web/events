﻿
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace faith
{
    public class ActivityHistoryWindows : Window
    {
        private readonly ListView activityList;

        public ActivityHistoryWindows()
        {
            Title = "CyberGuardBot - Activity History";
            Width = 750;
            Height = 500;
            MinWidth = 550;
            MinHeight = 350;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = new SolidColorBrush(
                Color.FromRgb(249, 245, 235));

            Grid mainGrid = new Grid
            {
                Margin = new Thickness(20)
            };

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            TextBlock heading = new TextBlock
            {
                Text = "Recent Activity",
                FontSize = 25,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(
                    Color.FromRgb(23, 36, 58)),
                Margin = new Thickness(0, 0, 0, 15)
            };

            Grid.SetRow(heading, 0);
            mainGrid.Children.Add(heading);

            activityList = new ListView
            {
                Margin = new Thickness(0, 0, 0, 15),
                Background = Brushes.White,
                BorderBrush = new SolidColorBrush(
                    Color.FromRgb(210, 210, 210))
            };

            GridView gridView = new GridView();

            gridView.Columns.Add(new GridViewColumn
            {
                Header = "Date and Time",
                Width = 180,
                DisplayMemberBinding =
                    new System.Windows.Data.Binding("Time")
            });

            gridView.Columns.Add(new GridViewColumn
            {
                Header = "Activity Description",
                Width = 470,
                DisplayMemberBinding =
                    new System.Windows.Data.Binding("Description")
            });

            activityList.View = gridView;

            Grid.SetRow(activityList, 1);
            mainGrid.Children.Add(activityList);

            StackPanel buttonPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            Button refreshButton = new Button
            {
                Content = "Refresh",
                Width = 100,
                Height = 35,
                Margin = new Thickness(5),
                Background = new SolidColorBrush(
                    Color.FromRgb(23, 36, 58)),
                Foreground = Brushes.White
            };

            refreshButton.Click += (sender, e) => LoadActivities();

            Button closeButton = new Button
            {
                Content = "Close",
                Width = 100,
                Height = 35,
                Margin = new Thickness(5),
                Background = Brushes.Gray,
                Foreground = Brushes.White
            };

            closeButton.Click += (sender, e) => Close();

            buttonPanel.Children.Add(refreshButton);
            buttonPanel.Children.Add(closeButton);

            Grid.SetRow(buttonPanel, 2);
            mainGrid.Children.Add(buttonPanel);

            Content = mainGrid;

            LoadActivities();
        }

        private void LoadActivities()
        {
            activityList.Items.Clear();

            var activities = ActivityTracker.GetLatest(10);

            foreach (var activity in activities)
            {
                activityList.Items.Add(new
                {
                    Time = activity.Timestamp.ToString(
                        "dd/MM/yyyy HH:mm:ss"),
                    activity.Description
                });
            }

            if (activities.Count == 0)
            {
                activityList.Items.Add(new
                {
                    Time = "",
                    Description = "No activities recorded yet."
                });
            }
        }
    }
}
