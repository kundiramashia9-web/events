﻿

using faith;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Media;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace FAITH
{
    public partial class MainWindow : Window
    {
        private readonly string dataFolder = Path.Combine(
            Environment.GetFolderPath(
                Environment.SpecialFolder.LocalApplicationData),
            "CyberGuardBot");

        private string HistoryFile =>
            Path.Combine(dataFolder, "conversations.json");

        private readonly List<ChatConversation> conversations = new();

        private ChatConversation? currentConversation;
        private SoundPlayer? greetingPlayer;
        private bool updatingHistory;
        private bool awaitingName = true;

        private readonly JsonSerializerOptions jsonOptions = new()
        {
            WriteIndented = true
        };

        public MainWindow()
        {
            InitializeComponent();
            ActivityTracker.Log("CyberGuardBot application started.");
            Directory.CreateDirectory(dataFolder);

            LoadConversations();
            RefreshHistoryList();

            currentConversation = null;
            awaitingName = true;

            NameEntryPanel.Visibility = Visibility.Visible;
            MessageEntryPanel.Visibility = Visibility.Collapsed;

            PersonNameTextBox.Clear();
            CurrentPersonTextBlock.Text = "Welcome to CyberGuardBot";

            ShowMessage(
                "CyberGuardBot",
                "Hello! Welcome to CyberGuardBot.\n\n" +
                "Please enter your name below and click Start Chat. " +
                "I will show you the cybersecurity topics you can ask about.");

            StatusTextBlock.Text = "Enter your name below to begin.";

            ChangePersonButton.Visibility = Visibility.Collapsed;

            PlayGreetingSound();
        }

        // DATA CLASSES

        public class ChatMessage
        {
            public string Sender { get; set; } = "";
            public string Text { get; set; } = "";
            public DateTime Timestamp { get; set; } = DateTime.Now;
        }

        public class ChatConversation
        {
            public string Id { get; set; } =
                Guid.NewGuid().ToString();

            public string Name { get; set; } = "";

            public DateTime CreatedAt { get; set; } = DateTime.Now;

            public DateTime UpdatedAt { get; set; } = DateTime.Now;

            public List<ChatMessage> Messages { get; set; } = new();

            public string DisplayName =>
                $"{Name} - {UpdatedAt:dd MMM yyyy HH:mm}";
        }

        // START CHAT

        private void StartChatButton_Click(
            object sender, RoutedEventArgs e)
        {
            string name = PersonNameTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show(
                    "Please enter your name first.",
                    "Name Required",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);

                PersonNameTextBox.Focus();
                return;
            }

            ChatConversation? existing = conversations.FirstOrDefault(c =>
                c.Name.Trim().Equals(
                    name,
                    StringComparison.OrdinalIgnoreCase));

            bool isNewConversation = existing == null;

            if (existing != null)
            {
                currentConversation = existing;
            }
            else
            {
                currentConversation = new ChatConversation
                {
                    Id = Guid.NewGuid().ToString(),
                    Name = name,
                    CreatedAt = DateTime.Now,
                    UpdatedAt = DateTime.Now
                };

                conversations.Add(currentConversation);
            }

            awaitingName = false;

            NameEntryPanel.Visibility = Visibility.Collapsed;
            MessageEntryPanel.Visibility = Visibility.Visible;
            ChangePersonButton.Visibility = Visibility.Visible;

            DisplayConversation();

            CurrentPersonTextBlock.Text = $"Conversation: {name}";

            if (isNewConversation)
            {
                AddSavedMessage(
                    "CyberGuardBot",
                    $"Hello, {name}! Welcome to CyberGuardBot.");

                AddSavedMessage(
                    "CyberGuardBot",
                    "I can help you learn about cybersecurity and staying safe online.");
            }
            else
            {
                AddSavedMessage(
                    "CyberGuardBot",
                    $"Welcome back, {name}! Your saved conversation has been loaded.");
            }

            AddSavedMessage("CyberGuardBot", GetTopics());

            currentConversation!.UpdatedAt = DateTime.Now;

            SaveConversations();
            RefreshHistoryList();

            StatusTextBlock.Text =
                $"Chat ready for {name}. Type your question below.";

            MessageTextBox.Focus();
        }

        // CHANGE PERSON

        private void ChangePersonButton_Click(
            object sender, RoutedEventArgs e)
        {
            SaveConversations();

            currentConversation = null;
            awaitingName = true;

            ConversationPanel.Children.Clear();

            CurrentPersonTextBlock.Text = "Welcome to CyberGuardBot";

            NameEntryPanel.Visibility = Visibility.Visible;
            MessageEntryPanel.Visibility = Visibility.Collapsed;
            ChangePersonButton.Visibility = Visibility.Collapsed;

            PersonNameTextBox.Clear();
            PersonNameTextBox.Focus();

            ShowMessage(
                "CyberGuardBot",
                "Who is using CyberGuardBot now? " +
                "Enter your name below to load your history or start a new chat.");

            StatusTextBlock.Text = "Enter a name to continue.";
        }

        // TASK ASSISTANT

        private void TaskAssistantButton_Click(
            object sender, RoutedEventArgs e)
        {
            TaskAssistantWindow taskWindow = new()
            {
                Owner = this
            };

            taskWindow.ShowDialog();
        }

        // SEND MESSAGES

        private void SendButton_Click(
            object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void MessageTextBox_PreviewKeyDown(
            object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                SendMessage();
            }
        }

        private void SendMessage()
        {
            string text = MessageTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(text))
                return;

            if (currentConversation == null || awaitingName)
            {
                StatusTextBlock.Text =
                    "Please enter your name and click Start Chat first.";
                return;
            }

            MessageTextBox.Clear();

            AddSavedMessage("You", text);

            string reply = GetResponse(text);

            AddSavedMessage("CyberGuardBot", reply);

            currentConversation.UpdatedAt = DateTime.Now;

            SaveConversations();
            RefreshHistoryList();

            StatusTextBlock.Text = "Message sent.";
            MessageTextBox.Focus();
        }

        // NATURAL LANGUAGE PROCESSING (NLP)

        private string? DetectNlpIntent(string input)
        {
            string message = input.Trim().ToLowerInvariant();

            // Task management
            if (ContainsAny(message,
                "task assistant",
                "open tasks",
                "manage tasks",
                "my tasks",
                "to do list",
                "todo list"))
            {
                return "I recognised that you want to manage tasks.\n\n" +
                       "Click the Task Assistant button to add, view, " +
                       "complete or delete your tasks.";
            }

            // Reminders
            if (ContainsAny(message,
                "reminder",
                "remind me",
                "remind",
                "remember to"))
            {
                return "I recognised that you need a reminder.\n\n" +
                       "Open Task Assistant, add a task and select " +
                       "a reminder date and time.";
            }

            // Quiz
            if (ContainsAny(message,
                "quiz",
                "test my knowledge",
                "cybersecurity questions",
                "start a test"))
            {
                return "I recognised that you want to take the cybersecurity quiz.\n\n" +
                       "Click the Cybersecurity Quiz button to start the 12-question quiz.";
            }

            // Activity log
            if (ContainsAny(message,
                "activity log",
                "recent activities",
                "latest actions",
                "activity history"))
            {
                return "I recognised that you want to view the Activity Log.\n\n" +
                       "The Activity Log feature will be connected when it is added.";
            }

            // Password security
            if (ContainsAny(message,
                "password",
                "passphrase",
                "strong password"))
            {
                return null; // Use the detailed password answer below.
            }

            // Phishing
            if (ContainsAny(message,
                "phishing",
                "fake email",
                "scam",
                "suspicious message",
                "suspicious email"))
            {
                return null;
            }

            // Malware
            if (ContainsAny(message,
                "malware",
                "virus",
                "ransomware",
                "spyware"))
            {
                return null;
            }

            // Multi-factor authentication
            if (ContainsAny(message,
                "mfa",
                "2fa",
                "two factor",
                "two-factor",
                "multi-factor",
                "authentication"))
            {
                return null;
            }

            // Social engineering
            if (ContainsAny(message,
                "social engineering",
                "manipulation",
                "pretending to be someone"))
            {
                return null;
            }

            // Privacy
            if (ContainsAny(message,
                "privacy",
                "personal information",
                "data protection"))
            {
                return null;
            }

            // Public Wi-Fi
            if (ContainsAny(message,
                "public wifi",
                "public wi-fi",
                "free wifi",
                "open wifi"))
            {
                return null;
            }

            // Software updates
            if (ContainsAny(message,
                "software update",
                "updates",
                "patch",
                "update my computer"))
            {
                return null;
            }

            // Backups
            if (ContainsAny(message,
                "backup",
                "backups",
                "restore files",
                "save my files"))
            {
                return null;
            }

            return null;
        }

        private bool ContainsAny(string message, params string[] keywords)
        {
            return keywords.Any(keyword =>
                message.Contains(
                    keyword,
                    StringComparison.OrdinalIgnoreCase));
        }

        // CHATBOT RESPONSES

        private string GetResponse(string input)
        {
            // Check NLP before the normal chatbot responses.
            string? nlpResponse = DetectNlpIntent(input);

            if (!string.IsNullOrEmpty(nlpResponse))
            {
                return nlpResponse;
            }

            string text = input.Trim().ToLowerInvariant();

            if (Regex.IsMatch(
                text,
                @"\b(hello|hi|hey|good morning|good afternoon|good evening)\b"))
            {
                return $"Hello, {currentConversation?.Name}! " +
                       "What cybersecurity topic would you like to discuss?";
            }

            if (text.Contains("topic") ||
                text.Contains("what can you do") ||
                text == "help")
            {
                return GetTopics();
            }

            // Task Assistant
            if (text.Contains("task assistant") ||
                text.Contains("open tasks") ||
                text.Contains("my tasks") ||
                text.Contains("manage tasks"))
            {
                return "You can open the Task Assistant using the Task Assistant button at the top of the application. " +
                       "There you can add, view, complete and delete cybersecurity tasks.";
            }

            // Password safety
            if (text.Contains("password") || text.Contains("passphrase"))
            {
                return "PASSWORD SAFETY\n\n" +
                       "• Use long, unique passwords for every account.\n" +
                       "• Consider a reputable password manager.\n" +
                       "• Never share your passwords.\n" +
                       "• Enable multi-factor authentication.\n" +
                       "• Avoid easily guessed personal information.";
            }

            // Phishing and scams
            if (text.Contains("phishing") ||
                text.Contains("scam") ||
                text.Contains("fake email") ||
                text.Contains("suspicious email"))
            {
                return "PHISHING AND SCAMS\n\n" +
                       "Phishing tries to trick people into revealing " +
                       "information or clicking unsafe links.\n\n" +
                       "• Check the sender's email address.\n" +
                       "• Be cautious about urgent requests.\n" +
                       "• Avoid suspicious attachments and links.\n" +
                       "• Verify messages using official contact details.";
            }

            // Multi-factor authentication
            if (text.Contains("mfa") ||
                text.Contains("2fa") ||
                text.Contains("two-factor") ||
                text.Contains("two factor") ||
                text.Contains("multi-factor") ||
                text.Contains("authentication"))
            {
                return "MULTI-FACTOR AUTHENTICATION\n\n" +
                       "MFA adds an extra security check when you sign in. " +
                       "For example, you may need your password and a code " +
                       "from an authentication app. This helps protect your " +
                       "account if your password is stolen.";
            }

            // Social engineering
            if (text.Contains("social engineering"))
            {
                return "SOCIAL ENGINEERING\n\n" +
                       "Social engineering is when someone manipulates " +
                       "people into revealing information or doing something unsafe.\n\n" +
                       "Verify identities, question unexpected requests, " +
                       "and never rush to share confidential information.";
            }

            // Malware
            if (text.Contains("malware") ||
                text.Contains("virus") ||
                text.Contains("ransomware") ||
                text.Contains("spyware"))
            {
                return "MALWARE\n\n" +
                       "Malware is software designed to harm devices or steal data. " +
                       "Examples include viruses, spyware, and ransomware.\n\n" +
                       "Keep software updated, avoid unknown downloads, " +
                       "use trusted security tools, and back up important files.";
            }

            // Privacy
            if (text.Contains("privacy") ||
                text.Contains("personal information") ||
                text.Contains("data protection"))
            {
                return "ONLINE PRIVACY\n\n" +
                       "• Limit personal information shared publicly.\n" +
                       "• Review your account privacy settings.\n" +
                       "• Check app permissions.\n" +
                       "• Never share passwords in messages.\n" +
                       "• Use trusted websites and apps.";
            }

            // Public Wi-Fi
            if (text.Contains("wi-fi") ||
                text.Contains("wifi") ||
                text.Contains("public network"))
            {
                return "PUBLIC WI-FI SAFETY\n\n" +
                       "Check the network name before connecting. " +
                       "Use secure websites, keep your device updated, " +
                       "and avoid sensitive transactions on networks you do not trust.";
            }

            // Software updates
            if (text.Contains("update") || text.Contains("patch"))
            {
                return "SOFTWARE UPDATES\n\n" +
                       "Updates fix bugs and security weaknesses. " +
                       "Keep your operating system, browser, and apps updated. " +
                       "Install updates from official sources.";
            }

            // Backups
            if (text.Contains("backup") || text.Contains("recover files"))
            {
                return "BACKUPS\n\n" +
                       "Backups help restore important files if a device is lost, " +
                       "damaged, or affected by malware. Keep a copy in a separate " +
                       "location and check that your backups can be restored.";
            }

            // Account security
            if (text.Contains("hacked") ||
                text.Contains("account stolen") ||
                text.Contains("account security"))
            {
                return "ACCOUNT SECURITY\n\n" +
                       "If you think your account has been compromised:\n" +
                       "• Visit the service's official website or app.\n" +
                       "• Change your password.\n" +
                       "• Sign out unfamiliar sessions if possible.\n" +
                       "• Enable multi-factor authentication.\n" +
                       "• Contact official support if needed.";
            }

            if (Regex.IsMatch(text, @"\b(thanks|thank you)\b"))
            {
                return "You're welcome! Staying informed helps you stay safer online.";
            }

            if (Regex.IsMatch(text, @"\b(bye|goodbye)\b"))
            {
                return $"Goodbye, {currentConversation?.Name}! Stay safe online.";
            }

            return "I do not understand that question yet, but I can help " +
                   "with cybersecurity topics.\n\n" +
                   "Try asking about passwords, phishing, MFA, social engineering, " +
                   "malware, privacy, public Wi-Fi, updates, backups, or account security. " +
                   "You can also ask about the Task Assistant and reminders.";
        }

        // TOPICS

        private string GetTopics()
        {
            return "CYBERGUARDBOT TOPICS\n\n" +
                   "1. Passwords and passphrases\n" +
                   "2. Phishing and online scams\n" +
                   "3. Multi-factor authentication (MFA)\n" +
                   "4. Social engineering\n" +
                   "5. Malware, viruses, and ransomware\n" +
                   "6. Online privacy\n" +
                   "7. Public Wi-Fi safety\n" +
                   "8. Software updates\n" +
                   "9. Backups and file recovery\n" +
                   "10. Account security\n" +
                   "11. Task Assistant\n" +
                   "12. Reminders\n" +
                   "13. Cybersecurity Quiz\n" +
                   "14. Activity Log\n\n" +
                   "Type a question about any topic to get started.";
        }

        private void HelpButton_Click(
            object sender, RoutedEventArgs e)
        {
            if (currentConversation == null || awaitingName)
            {
                StatusTextBlock.Text =
                    "Please enter your name and click Start Chat first.";
                PersonNameTextBox.Focus();
                return;
            }

            AddSavedMessage("You", "Show me the available topics.");
            AddSavedMessage("CyberGuardBot", GetTopics());

            currentConversation.UpdatedAt = DateTime.Now;

            SaveConversations();
            RefreshHistoryList();
        }

        // SAVE AND DISPLAY MESSAGES

        private void AddSavedMessage(string sender, string text)
        {
            if (currentConversation == null)
                return;

            ChatMessage message = new()
            {
                Sender = sender,
                Text = text,
                Timestamp = DateTime.Now
            };

            currentConversation.Messages.Add(message);
            currentConversation.UpdatedAt = DateTime.Now;

            ShowMessage(sender, text, message.Timestamp);
            SaveConversations();
        }

        private void ShowMessage(
            string sender,
            string text,
            DateTime? timestamp = null)
        {
            bool isUser = sender == "You";

            StackPanel container = new()
            {
                HorizontalAlignment = isUser
                    ? HorizontalAlignment.Right
                    : HorizontalAlignment.Left,
                MaxWidth = 650,
                Margin = new Thickness(4, 5, 4, 5)
            };

            TextBlock senderLabel = new()
            {
                Text = sender,
                FontWeight = FontWeights.Bold,
                FontSize = 12,
                Foreground = new SolidColorBrush(
                    isUser
                        ? Color.FromRgb(23, 36, 58)
                        : Color.FromRgb(65, 91, 122)),
                Margin = new Thickness(4, 0, 4, 3)
            };

            StackPanel bubbleContent = new();

            bubbleContent.Children.Add(new TextBlock
            {
                Text = text,
                TextWrapping = TextWrapping.Wrap,
                FontSize = 14,
                Foreground = new SolidColorBrush(
                    Color.FromRgb(23, 36, 58))
            });

            bubbleContent.Children.Add(new TextBlock
            {
                Text = (timestamp ?? DateTime.Now).ToString("HH:mm"),
                FontSize = 10,
                Foreground = Brushes.Gray,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 5, 0, 0)
            });

            Border bubble = new()
            {
                Background = new SolidColorBrush(
                    isUser
                        ? Color.FromRgb(232, 237, 245)
                        : Color.FromRgb(255, 249, 239)),
                BorderBrush = new SolidColorBrush(
                    Color.FromRgb(216, 207, 191)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(9),
                Padding = new Thickness(12),
                Child = bubbleContent
            };

            container.Children.Add(senderLabel);
            container.Children.Add(bubble);

            ConversationPanel.Children.Add(container);
            ConversationScrollViewer.ScrollToEnd();
        }

        // TASK BUTTON

        private void TaskButton_Click(object sender, RoutedEventArgs e)
        {
            TaskAssistantWindow taskWindow = new()
            {
                Owner = this
            };

            taskWindow.ShowDialog();
        }

        // QUIZ BUTTON

        private void QuizButton_Click(object sender, RoutedEventArgs e)
        {
            QuizWindow quizWindow = new()
            {
                Owner = this
            };

            quizWindow.ShowDialog();
        }

        // DISPLAY CONVERSATION

        private void DisplayConversation()
        {
            ConversationPanel.Children.Clear();

            if (currentConversation == null)
                return;

            CurrentPersonTextBlock.Text =
                $"Conversation: {currentConversation.Name}";

            foreach (ChatMessage message in currentConversation.Messages)
            {
                ShowMessage(
                    message.Sender,
                    message.Text,
                    message.Timestamp);
            }

            ConversationScrollViewer.ScrollToEnd();
        }

        // HISTORY LIST

        private void RefreshHistoryList()
        {
            updatingHistory = true;

            try
            {
                string? selectedId = currentConversation?.Id;

                List<ChatConversation> ordered = conversations
                    .OrderByDescending(c => c.UpdatedAt)
                    .ToList();

                HistoryListBox.ItemsSource = null;
                HistoryListBox.ItemsSource = ordered;

                HistoryListBox.SelectedItem = ordered.FirstOrDefault(
                    c => c.Id == selectedId);
            }
            finally
            {
                updatingHistory = false;
            }
        }

        private void HistoryListBox_SelectionChanged(
            object sender, SelectionChangedEventArgs e)
        {
            if (updatingHistory)
                return;

            if (HistoryListBox.SelectedItem is not ChatConversation selected)
                return;

            ChatConversation? found = conversations.FirstOrDefault(
                c => c.Id == selected.Id);

            if (found == null)
                return;

            currentConversation = found;
            awaitingName = false;

            NameEntryPanel.Visibility = Visibility.Collapsed;
            MessageEntryPanel.Visibility = Visibility.Visible;
            ChangePersonButton.Visibility = Visibility.Visible;

            DisplayConversation();

            StatusTextBlock.Text =
                $"Viewing {found.Name}'s saved conversation.";
        }

        // CLEAR CURRENT CHAT

        private void ClearButton_Click(
            object sender, RoutedEventArgs e)
        {
            if (currentConversation == null)
            {
                StatusTextBlock.Text =
                    "Start or select a conversation first.";
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                $"Clear all messages for {currentConversation.Name}?",
                "Clear Current Chat",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;

            currentConversation.Messages.Clear();
            ConversationPanel.Children.Clear();

            AddSavedMessage(
                "CyberGuardBot",
                $"This conversation has been cleared. How can I help you, " +
                $"{currentConversation.Name}?");

            currentConversation.UpdatedAt = DateTime.Now;

            SaveConversations();
            RefreshHistoryList();

            StatusTextBlock.Text = "Current conversation cleared.";
        }

        // SAVE CONVERSATIONS

        private void SaveConversations()
        {
            try
            {
                Directory.CreateDirectory(dataFolder);

                string json = JsonSerializer.Serialize(
                    conversations,
                    jsonOptions);

                string temporaryFile = HistoryFile + ".tmp";

                File.WriteAllText(temporaryFile, json);

                File.Move(
                    temporaryFile,
                    HistoryFile,
                    overwrite: true);
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text =
                    "Could not save history: " + ex.Message;
            }
        }

        // LOAD CONVERSATIONS

        private void LoadConversations()
        {
            try
            {
                if (!File.Exists(HistoryFile))
                    return;

                string json = File.ReadAllText(HistoryFile);

                List<ChatConversation>? loaded =
                    JsonSerializer.Deserialize<List<ChatConversation>>(json);

                if (loaded == null)
                    return;

                conversations.Clear();
                conversations.AddRange(loaded);

                foreach (ChatConversation conversation in conversations)
                {
                    conversation.Messages ??= new List<ChatMessage>();

                    if (string.IsNullOrWhiteSpace(conversation.Id))
                        conversation.Id = Guid.NewGuid().ToString();

                    if (string.IsNullOrWhiteSpace(conversation.Name))
                        conversation.Name = "Guest";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Could not load chat history.\n\n" + ex.Message,
                    "Chat History",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);
            }
        }

        // GREETING SOUND ONLY

        private void PlayGreetingSound()
        {
            string soundFile = Path.Combine(
                AppContext.BaseDirectory,
                "WhatsApp Ptt 2026-08-19 at 12.43.50 - Copy.wav");

            try
            {
                if (!File.Exists(soundFile))
                {
                    StatusTextBlock.Text =
                        "Greeting WAV not found. You can still use the chatbot.";
                    return;
                }

                greetingPlayer = new SoundPlayer(soundFile);
                greetingPlayer.Load();
                greetingPlayer.Play();
            }
            catch (Exception ex)
            {
                StatusTextBlock.Text =
                    "Greeting sound could not play: " + ex.Message;
            }
        }
        private void ActivityLogButton_Click(object sender, RoutedEventArgs e)
        {
            ActivityHistoryWindows activityWindow =
                new ActivityHistoryWindows
                {
                    Owner = this
                };

            activityWindow.ShowDialog();
        }


        // CLOSE WINDOW

        private void Window_Closed(object? sender, EventArgs e)
        {
            SaveConversations();

            if (greetingPlayer != null)
            {
                greetingPlayer.Stop();
                greetingPlayer.Dispose();
                greetingPlayer = null;
            }
        }
    }
}
