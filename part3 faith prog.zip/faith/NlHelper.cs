﻿
using System;
using System.Linq;

namespace faith
{
    public enum NlpIntent
    {
        None,
        Task,
        Reminder,
        Quiz,
        ActivityLog,
        Password,
        Phishing,
        Malware,
        Privacy,
        Mfa,
        SocialEngineering,
        Wifi,
        Updates,
        Backup
    }

    public class NlpResult
    {
        public NlpIntent Intent { get; set; }
        public string Response { get; set; } = "";
    }

    public static class NlpHelper
    {
        public static NlpResult DetectIntent(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                return new NlpResult
                {
                    Intent = NlpIntent.None,
                    Response = "Please enter a message so I can help you."
                };
            }

            string message = input.ToLowerInvariant();

            // TASK MANAGEMENT
            if (ContainsAny(message, "add a task", "create a task",
                "new task", "my tasks", "task assistant", "manage tasks"))
            {
                return Result(NlpIntent.Task,
                    "I can help you manage cybersecurity tasks. Open Task Assistant to add, view, complete or delete tasks.");
            }

            // REMINDERS
            if (ContainsAny(message, "remind me", "set a reminder",
                "reminder", "remind me tomorrow", "don't let me forget"))
            {
                return Result(NlpIntent.Reminder,
                    "You can set a reminder for a cybersecurity task using the Task Assistant. Choose a future date and time.");
            }

            // QUIZ
            if (ContainsAny(message, "quiz", "test my knowledge",
                "start a test", "cybersecurity questions",
                "mini game", "mini-game"))
            {
                return Result(NlpIntent.Quiz,
                    "Let's test your cybersecurity knowledge! Open the Cybersecurity Quiz to answer 12 questions.");
            }

            // ACTIVITY LOG
            if (ContainsAny(message, "activity log", "show my activities",
                "recent actions", "what have i done",
                "show activity", "my activity"))
            {
                return Result(NlpIntent.ActivityLog,
                    "You are asking to view your recent activities. The Activity Log feature will record and display your latest actions.");
            }

            // PASSWORD SECURITY
            if (ContainsAny(message, "password", "passphrase",
                "strong password", "password security"))
            {
                return Result(NlpIntent.Password,
                    "Use a long, unique password or passphrase for each account. Consider using a password manager and enable multi-factor authentication.");
            }

            // PHISHING
            if (ContainsAny(message, "phishing", "fake email",
                "suspicious email", "scam", "scam message",
                "fake message", "suspicious link"))
            {
                return Result(NlpIntent.Phishing,
                    "Be careful with unexpected messages and links. Check the sender, avoid sharing personal information, and verify suspicious requests through official channels.");
            }

            // MALWARE
            if (ContainsAny(message, "malware", "virus",
                "ransomware", "spyware", "malicious software"))
            {
                return Result(NlpIntent.Malware,
                    "Malware is software designed to harm or access devices without permission. Keep your software updated and use trusted security protection.");
            }

            // MFA
            if (ContainsAny(message, "mfa", "2fa",
                "two factor", "two-factor",
                "multi factor", "multi-factor",
                "authentication"))
            {
                return Result(NlpIntent.Mfa,
                    "Multi-factor authentication adds another verification step when signing in. It helps protect your account even if your password is exposed.");
            }

            // SOCIAL ENGINEERING
            if (ContainsAny(message, "social engineering",
                "manipulation", "impersonation", "pretending to be someone"))
            {
                return Result(NlpIntent.SocialEngineering,
                    "Social engineering involves manipulating people into revealing information or taking unsafe actions. Always verify unusual requests.");
            }

            // PRIVACY
            if (ContainsAny(message, "privacy", "personal information",
                "protect my data", "data protection",
                "online safety"))
            {
                return Result(NlpIntent.Privacy,
                    "Protect your personal information by reviewing privacy settings, limiting what you share and using trusted websites.");
            }

            // PUBLIC WI-FI
            if (ContainsAny(message, "public wifi", "public wi-fi",
                "free wifi", "free wi-fi", "wireless network"))
            {
                return Result(NlpIntent.Wifi,
                    "Public Wi-Fi can be risky. Avoid sensitive activities on untrusted networks and use secure websites.");
            }

            // SOFTWARE UPDATES
            if (ContainsAny(message, "software update", "updates",
                "patch", "update my computer"))
            {
                return Result(NlpIntent.Updates,
                    "Keep your operating system and applications updated. Updates often fix security weaknesses.");
            }

            // BACKUPS
            if (ContainsAny(message, "backup", "backups",
                "save my files", "recover my files",
                "data recovery"))
            {
                return Result(NlpIntent.Backup,
                    "Back up important files regularly. Keep a separate copy so you can recover information if your device fails or files are lost.");
            }

            return new NlpResult
            {
                Intent = NlpIntent.None,
                Response = ""
            };
        }

        private static bool ContainsAny(string message, params string[] keywords)
        {
            return keywords.Any(keyword =>
                message.Contains(keyword, StringComparison.OrdinalIgnoreCase));
        }

        private static NlpResult Result(NlpIntent intent, string response)
        {
            return new NlpResult
            {
                Intent = intent,
                Response = response
            };
        }
    }
}
