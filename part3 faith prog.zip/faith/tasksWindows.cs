﻿




using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace faith
{
    public class CyberTask
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Title { get; set; } = "";
        public string Description { get; set; } = "";
        public DateTime? Reminder { get; set; }
        public bool IsCompleted { get; set; }
        public bool ReminderShown { get; set; }
    }

    public class TaskAssistantWindow : Window
    {
        private readonly string taskFile = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "CyberGuardBot",
            "tasks.json");

        private List<CyberTask> tasks = new();

        private TextBox titleBox = null!;
        private TextBox descriptionBox = null!;
        private DatePicker reminderDatePicker = null!;
        private TextBox reminderTimeBox = null!;
        private ListBox taskListBox = null!;
        private TextBlock statusText = null!;

        private readonly DispatcherTimer reminderTimer = new();

        private readonly Brush navyBrush =
            new SolidColorBrush(Color.FromRgb(23, 36, 58));

        public TaskAssistantWindow()
        {
            Title = "CyberGuardBot - Task Assistant";
            Width = 850;
            Height = 650;
            MinWidth = 650;
            MinHeight = 500;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = new SolidColorBrush(Color.FromRgb(255, 249, 239));
            FontFamily = new FontFamily("Segoe UI");

            BuildInterface();
            LoadTasks();
            RefreshTaskList();

            ActivityTracker.Log("Task Assistant opened.");

            reminderTimer.Interval = TimeSpan.FromSeconds(15);
            reminderTimer.Tick += ReminderTimer_Tick;
            reminderTimer.Start();

            Closed += (sender, args) =>
            {
                reminderTimer.Stop();
                ActivityTracker.Log("Task Assistant closed.");
            };
        }

        private void BuildInterface()
        {
            Grid mainGrid = new();
            mainGrid.Margin = new Thickness(20);

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            Content = mainGrid;

            TextBlock heading = new()
            {
                Text = "Cybersecurity Task Assistant",
                FontSize = 25,
                FontWeight = FontWeights.Bold,
                Foreground = navyBrush,
                Margin = new Thickness(0, 0, 0, 15)
            };

            Grid.SetRow(heading, 0);
            mainGrid.Children.Add(heading);

            Grid contentGrid = new();

            contentGrid.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            contentGrid.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            Grid.SetRow(contentGrid, 1);
            mainGrid.Children.Add(contentGrid);

            // ADD TASK SECTION

            StackPanel addPanel = new()
            {
                Margin = new Thickness(0, 0, 15, 0)
            };

            addPanel.Children.Add(new TextBlock
            {
                Text = "Add a New Task",
                FontSize = 19,
                FontWeight = FontWeights.Bold,
                Foreground = navyBrush,
                Margin = new Thickness(0, 0, 0, 12)
            });

            addPanel.Children.Add(CreateLabel("Task title"));

            titleBox = new TextBox
            {
                Height = 35,
                Padding = new Thickness(8),
                Margin = new Thickness(0, 4, 0, 12)
            };

            addPanel.Children.Add(titleBox);

            addPanel.Children.Add(CreateLabel("Task description"));

            descriptionBox = new TextBox
            {
                Height = 100,
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Padding = new Thickness(8),
                Margin = new Thickness(0, 4, 0, 12)
            };

            addPanel.Children.Add(descriptionBox);

            addPanel.Children.Add(CreateLabel("Reminder date (optional)"));

            reminderDatePicker = new DatePicker
            {
                Height = 35,
                Margin = new Thickness(0, 4, 0, 12)
            };

            addPanel.Children.Add(reminderDatePicker);

            addPanel.Children.Add(CreateLabel("Reminder time (HH:mm)"));

            reminderTimeBox = new TextBox
            {
                Height = 35,
                Padding = new Thickness(8),
                Margin = new Thickness(0, 4, 0, 15),
                Text = "09:00"
            };

            addPanel.Children.Add(reminderTimeBox);

            Button addButton = CreateButton("Add Task");
            addButton.Click += AddTask_Click;
            addPanel.Children.Add(addButton);

            Grid.SetColumn(addPanel, 0);
            contentGrid.Children.Add(addPanel);

            // TASK LIST SECTION

            StackPanel listPanel = new()
            {
                Margin = new Thickness(15, 0, 0, 0)
            };

            listPanel.Children.Add(new TextBlock
            {
                Text = "My Tasks",
                FontSize = 19,
                FontWeight = FontWeights.Bold,
                Foreground = navyBrush,
                Margin = new Thickness(0, 0, 0, 12)
            });

            taskListBox = new ListBox
            {
                MinHeight = 250,
                Margin = new Thickness(0, 0, 0, 12),
                DisplayMemberPath = "Title"
            };

            taskListBox.SelectionChanged += TaskListBox_SelectionChanged;
            listPanel.Children.Add(taskListBox);

            Button completeButton = CreateButton("Mark as Completed");
            completeButton.Click += CompleteTask_Click;
            listPanel.Children.Add(completeButton);

            Button deleteButton = CreateButton("Delete Task");
            deleteButton.Margin = new Thickness(0, 8, 0, 0);
            deleteButton.Click += DeleteTask_Click;
            listPanel.Children.Add(deleteButton);

            Grid.SetColumn(listPanel, 1);
            contentGrid.Children.Add(listPanel);

            statusText = new TextBlock
            {
                Text = "Ready",
                Foreground = navyBrush,
                FontSize = 13,
                Margin = new Thickness(0, 15, 0, 0)
            };

            Grid.SetRow(statusText, 2);
            mainGrid.Children.Add(statusText);
        }

        private TextBlock CreateLabel(string text)
        {
            return new TextBlock
            {
                Text = text,
                FontWeight = FontWeights.SemiBold,
                Foreground = navyBrush
            };
        }

        private Button CreateButton(string text)
        {
            return new Button
            {
                Content = text,
                Height = 38,
                Padding = new Thickness(10, 5, 10, 5),
                Background = navyBrush,
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0),
                FontWeight = FontWeights.SemiBold,
                Cursor = System.Windows.Input.Cursors.Hand
            };
        }

        // ADD TASK

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            string title = titleBox.Text.Trim();
            string description = descriptionBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(title))
            {
                MessageBox.Show("Please enter a task title.");
                return;
            }

            DateTime? reminder = null;

            if (reminderDatePicker.SelectedDate.HasValue)
            {
                if (!TimeSpan.TryParseExact(
                    reminderTimeBox.Text.Trim(),
                    @"hh\:mm",
                    null,
                    out TimeSpan reminderTime))
                {
                    MessageBox.Show(
                        "Enter the reminder time in HH:mm format, for example 14:30.");
                    return;
                }

                reminder = reminderDatePicker.SelectedDate.Value.Date
                    .Add(reminderTime);

                if (reminder.Value <= DateTime.Now)
                {
                    MessageBox.Show(
                        "Please select a future reminder date and time.");
                    return;
                }
            }

            CyberTask newTask = new()
            {
                Title = title,
                Description = description,
                Reminder = reminder
            };

            tasks.Add(newTask);

            // ACTIVITY LOGGING
            ActivityTracker.Log("Task added: " + newTask.Title);

            if (newTask.Reminder.HasValue)
            {
                ActivityTracker.Log(
                    "Reminder created for task: " + newTask.Title +
                    " at " + newTask.Reminder.Value.ToString("dd/MM/yyyy HH:mm"));
            }

            SaveTasks();
            RefreshTaskList();

            titleBox.Clear();
            descriptionBox.Clear();
            reminderDatePicker.SelectedDate = null;
            reminderTimeBox.Text = "09:00";

            statusText.Text = "Task added successfully.";

            MessageBox.Show("Your task has been added.");
        }

        // VIEW TASK DETAILS

        private void TaskListBox_SelectionChanged(
            object sender,
            SelectionChangedEventArgs e)
        {
            if (taskListBox.SelectedItem is not CyberTask selectedTask)
                return;

            string reminderText = selectedTask.Reminder.HasValue
                ? selectedTask.Reminder.Value.ToString("dd MMM yyyy HH:mm")
                : "No reminder set";

            string completionText = selectedTask.IsCompleted
                ? "Completed"
                : "Pending";

            MessageBox.Show(
                $"Title: {selectedTask.Title}\n\n" +
                $"Description: {selectedTask.Description}\n\n" +
                $"Reminder: {reminderText}\n\n" +
                $"Status: {completionText}",
                "Task Details");
        }

        // MARK COMPLETED

        private void CompleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (taskListBox.SelectedItem is not CyberTask selectedTask)
            {
                MessageBox.Show("Please select a task first.");
                return;
            }

            if (selectedTask.IsCompleted)
            {
                MessageBox.Show("This task is already completed.");
                return;
            }

            selectedTask.IsCompleted = true;

            // ACTIVITY LOGGING
            ActivityTracker.Log("Task completed: " + selectedTask.Title);

            SaveTasks();
            RefreshTaskList();

            statusText.Text = "Task marked as completed.";

            MessageBox.Show("Your task has been completed.");
        }

        // DELETE TASK

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (taskListBox.SelectedItem is not CyberTask selectedTask)
            {
                MessageBox.Show("Please select a task to delete.");
                return;
            }

            MessageBoxResult result = MessageBox.Show(
                $"Are you sure you want to delete '{selectedTask.Title}'?",
                "Confirm Delete",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
                return;

            // ACTIVITY LOGGING
            ActivityTracker.Log("Task deleted: " + selectedTask.Title);

            tasks.Remove(selectedTask);

            SaveTasks();
            RefreshTaskList();

            statusText.Text = "Task deleted.";
        }

        // CHECK REMINDERS

        private void ReminderTimer_Tick(object? sender, EventArgs e)
        {
            List<CyberTask> dueTasks = tasks
                .Where(t =>
                    !t.IsCompleted &&
                    !t.ReminderShown &&
                    t.Reminder.HasValue &&
                    t.Reminder.Value <= DateTime.Now)
                .ToList();

            foreach (CyberTask task in dueTasks)
            {
                task.ReminderShown = true;

                // ACTIVITY LOGGING
                ActivityTracker.Log("Reminder triggered for task: " + task.Title);

                MessageBox.Show(
                    $"Reminder: {task.Title}\n\n{task.Description}",
                    "CyberGuardBot Reminder");
            }

            if (dueTasks.Count > 0)
            {
                SaveTasks();
                RefreshTaskList();
            }
        }

        // REFRESH TASK LIST

        private void RefreshTaskList()
        {
            taskListBox.ItemsSource = null;

            taskListBox.ItemsSource = tasks
                .OrderBy(t => t.IsCompleted)
                .ThenBy(t => t.Reminder ?? DateTime.MaxValue)
                .ToList();
        }

        // SAVE TASKS

        private void SaveTasks()
        {
            try
            {
                string? folder = Path.GetDirectoryName(taskFile);

                if (!string.IsNullOrWhiteSpace(folder))
                    Directory.CreateDirectory(folder);

                string json = JsonSerializer.Serialize(
                    tasks,
                    new JsonSerializerOptions { WriteIndented = true });

                File.WriteAllText(taskFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Could not save tasks: " + ex.Message);
            }
        }

        // LOAD TASKS

        private void LoadTasks()
        {
            try
            {
                if (!File.Exists(taskFile))
                {
                    tasks = new List<CyberTask>();
                    return;
                }

                string json = File.ReadAllText(taskFile);

                tasks = JsonSerializer.Deserialize<List<CyberTask>>(json)
                        ?? new List<CyberTask>();
            }
            catch (Exception ex)
            {
                tasks = new List<CyberTask>();
                MessageBox.Show("Could not load saved tasks: " + ex.Message);
            }
        }
    }
}
