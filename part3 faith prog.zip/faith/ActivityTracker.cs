﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace faith
{
    public class ActivityEntry
    {
        public string Description { get; set; } = "";
        public DateTime Timestamp { get; set; }
    }

    public static class ActivityTracker
    {
        private static readonly string FolderPath =
            Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "CyberGuardBot");

        private static readonly string FilePath =
            Path.Combine(FolderPath, "activity.json");

        private static readonly object LockObject = new object();

        // Record a new activity
        public static void Log(string description)
        {
            if (string.IsNullOrWhiteSpace(description))
                return;

            lock (LockObject)
            {
                try
                {
                    Directory.CreateDirectory(FolderPath);

                    List<ActivityEntry> activities = LoadActivities();

                    activities.Add(new ActivityEntry
                    {
                        Description = description.Trim(),
                        Timestamp = DateTime.Now
                    });

                    File.WriteAllText(
                        FilePath,
                        JsonSerializer.Serialize(
                            activities,
                            new JsonSerializerOptions
                            {
                                WriteIndented = true
                            }));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(
                        "Activity logging error: " + ex.Message);
                }
            }
        }

        // Retrieve the latest activities
        public static List<ActivityEntry> GetLatest(int count = 10)
        {
            lock (LockObject)
            {
                try
                {
                    return LoadActivities()
                        .OrderByDescending(a => a.Timestamp)
                        .Take(Math.Max(0, count))
                        .ToList();
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(
                        "Activity retrieval error: " + ex.Message);

                    return new List<ActivityEntry>();
                }
            }
        }

        // Load activities from the JSON file
        private static List<ActivityEntry> LoadActivities()
        {
            if (!File.Exists(FilePath))
                return new List<ActivityEntry>();

            try
            {
                string json = File.ReadAllText(FilePath);

                return JsonSerializer.Deserialize<List<ActivityEntry>>(json)
                       ?? new List<ActivityEntry>();
            }
            catch
            {
                return new List<ActivityEntry>();
            }
        }
    }
}
