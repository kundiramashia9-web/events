﻿

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace faith
{
    public class QuizQuestion
    {
        public string Question { get; set; } = "";
        public string[] Options { get; set; } = Array.Empty<string>();
        public int CorrectAnswer { get; set; }
        public string Explanation { get; set; } = "";
    }

    public class QuizWindow : Window
    {
        private readonly List<QuizQuestion> questions = new()
        {
            new QuizQuestion
            {
                Question = "1. What is phishing?",
                Options = new[]
                {
                    "A type of computer hardware",
                    "A fraudulent attempt to steal personal information",
                    "A way to improve internet speed",
                    "A computer programming language"
                },
                CorrectAnswer = 1,
                Explanation = "Phishing uses deceptive messages or websites to trick people into revealing sensitive information."
            },

            new QuizQuestion
            {
                Question = "2. Should you share your password with strangers?",
                Options = new[] { "True", "False" },
                CorrectAnswer = 1,
                Explanation = "Never share your password with strangers. Keep your login details private."
            },

            new QuizQuestion
            {
                Question = "3. What does MFA stand for?",
                Options = new[]
                {
                    "Multiple File Access",
                    "Multi-Factor Authentication",
                    "Main Firewall Application",
                    "Managed File Account"
                },
                CorrectAnswer = 1,
                Explanation = "Multi-Factor Authentication uses additional verification to protect an account."
            },

            new QuizQuestion
            {
                Question = "4. What should you do with a suspicious email link?",
                Options = new[]
                {
                    "Click it immediately",
                    "Forward it to everyone",
                    "Avoid clicking and verify the sender",
                    "Enter your password"
                },
                CorrectAnswer = 2,
                Explanation = "Avoid suspicious links and verify unexpected messages through a trusted channel."
            },

            new QuizQuestion
            {
                Question = "5. Is it important to update your software?",
                Options = new[] { "True", "False" },
                CorrectAnswer = 0,
                Explanation = "Software updates often fix security weaknesses and improve protection."
            },

            new QuizQuestion
            {
                Question = "6. Which of these is an example of malware?",
                Options = new[]
                {
                    "Ransomware",
                    "Keyboard",
                    "Monitor",
                    "Printer"
                },
                CorrectAnswer = 0,
                Explanation = "Ransomware is malicious software that can prevent access to files or systems."
            },

            new QuizQuestion
            {
                Question = "7. What is the purpose of a firewall?",
                Options = new[]
                {
                    "To charge a laptop",
                    "To help monitor and control network traffic",
                    "To increase screen brightness",
                    "To create documents"
                },
                CorrectAnswer = 1,
                Explanation = "A firewall helps control incoming and outgoing network traffic according to security rules."
            },

            new QuizQuestion
            {
                Question = "8. Should you use the same password for every account?",
                Options = new[] { "True", "False" },
                CorrectAnswer = 1,
                Explanation = "Using different passwords reduces the risk of multiple accounts being compromised."
            },

            new QuizQuestion
            {
                Question = "9. What is social engineering?",
                Options = new[]
                {
                    "Building computer networks",
                    "Manipulating people into revealing information or taking unsafe actions",
                    "Installing computer applications",
                    "Creating strong passwords"
                },
                CorrectAnswer = 1,
                Explanation = "Social engineering tricks people into giving away information or access."
            },

            new QuizQuestion
            {
                Question = "10. Why should you back up important files?",
                Options = new[]
                {
                    "To make the computer heavier",
                    "To protect against data loss",
                    "To remove all passwords",
                    "To stop software updates"
                },
                CorrectAnswer = 1,
                Explanation = "Backups help you recover important information if files are lost or damaged."
            },

            new QuizQuestion
            {
                Question = "11. Is public Wi-Fi always safe for sensitive activities?",
                Options = new[] { "True", "False" },
                CorrectAnswer = 1,
                Explanation = "Public Wi-Fi can carry risks. Use secure websites and avoid sensitive activities on untrusted networks."
            },

            new QuizQuestion
            {
                Question = "12. Which password is generally strongest?",
                Options = new[]
                {
                    "123456",
                    "password",
                    "Kundi123",
                    "River!Cloud7#Garden"
                },
                CorrectAnswer = 3,
                Explanation = "A long, unique password or passphrase with varied characters is generally harder to guess."
            }
        };

        private int currentQuestion = 0;
        private int score = 0;
        private bool answered = false;

        private TextBlock questionNumberText = null!;
        private TextBlock questionText = null!;
        private TextBlock feedbackText = null!;
        private TextBlock scoreText = null!;
        private StackPanel optionsPanel = null!;
        private Button nextButton = null!;

        private readonly Brush navy =
            new SolidColorBrush(Color.FromRgb(23, 36, 58));

        private readonly Brush cream =
            new SolidColorBrush(Color.FromRgb(255, 249, 239));

        public QuizWindow()
        {
            Title = "CyberGuardBot - Cybersecurity Quiz";
            Width = 750;
            Height = 600;
            MinWidth = 600;
            MinHeight = 450;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = cream;
            FontFamily = new FontFamily("Segoe UI");

            BuildInterface();
            ShowQuestion();
        }

        private void BuildInterface()
        {
            Grid mainGrid = new();
            mainGrid.Margin = new Thickness(25);

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            mainGrid.RowDefinitions.Add(
                new RowDefinition { Height = GridLength.Auto });

            Content = mainGrid;

            TextBlock heading = new()
            {
                Text = "Cybersecurity Mini-Game",
                FontSize = 26,
                FontWeight = FontWeights.Bold,
                Foreground = navy,
                Margin = new Thickness(0, 0, 0, 15)
            };

            Grid.SetRow(heading, 0);
            mainGrid.Children.Add(heading);

            questionNumberText = new TextBlock
            {
                FontSize = 15,
                FontWeight = FontWeights.SemiBold,
                Foreground = navy,
                Margin = new Thickness(0, 0, 0, 15)
            };

            Grid.SetRow(questionNumberText, 1);
            mainGrid.Children.Add(questionNumberText);

            StackPanel questionPanel = new();

            questionText = new TextBlock
            {
                FontSize = 20,
                FontWeight = FontWeights.Bold,
                Foreground = navy,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 5, 0, 20)
            };

            questionPanel.Children.Add(questionText);

            optionsPanel = new StackPanel();
            questionPanel.Children.Add(optionsPanel);

            ScrollViewer scrollViewer = new()
            {
                Content = questionPanel,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };

            Grid.SetRow(scrollViewer, 2);
            mainGrid.Children.Add(scrollViewer);

            feedbackText = new TextBlock
            {
                FontSize = 14,
                FontWeight = FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 12, 0, 12),
                Foreground = navy
            };

            Grid.SetRow(feedbackText, 3);
            mainGrid.Children.Add(feedbackText);

            StackPanel bottomPanel = new()
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Stretch
            };

            scoreText = new TextBlock
            {
                Text = "Score: 0",
                FontSize = 15,
                FontWeight = FontWeights.Bold,
                Foreground = navy,
                VerticalAlignment = VerticalAlignment.Center
            };

            bottomPanel.Children.Add(scoreText);

            nextButton = new Button
            {
                Content = "Next Question",
                Width = 150,
                Height = 40,
                Background = navy,
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(0),
                HorizontalAlignment = HorizontalAlignment.Right,
                IsEnabled = false
            };

            nextButton.Click += NextButton_Click;

            StackPanel buttonHolder = new()
            {
                HorizontalAlignment = HorizontalAlignment.Right
            };

            buttonHolder.Children.Add(nextButton);

            Grid buttonGrid = new();
            buttonGrid.ColumnDefinitions.Add(new ColumnDefinition());
            buttonGrid.ColumnDefinitions.Add(new ColumnDefinition
            {
                Width = GridLength.Auto
            });

            Grid.SetColumn(scoreText, 0);
            Grid.SetColumn(buttonHolder, 1);

            bottomPanel.Children.Clear();

            buttonGrid.Children.Add(scoreText);
            buttonGrid.Children.Add(buttonHolder);

            Grid.SetRow(buttonGrid, 4);
            mainGrid.Children.Add(buttonGrid);
        }

        private void ShowQuestion()
        {
            if (currentQuestion >= questions.Count)
            {
                ShowResults();
                return;
            }

            answered = false;

            QuizQuestion question = questions[currentQuestion];

            questionNumberText.Text =
                $"Question {currentQuestion + 1} of {questions.Count}";

            questionText.Text = question.Question;

            feedbackText.Text = "";

            scoreText.Text = $"Score: {score}/{questions.Count}";

            nextButton.IsEnabled = false;

            nextButton.Content =
                currentQuestion == questions.Count - 1
                ? "View Results"
                : "Next Question";

            optionsPanel.Children.Clear();

            for (int i = 0; i < question.Options.Length; i++)
            {
                int selectedAnswer = i;

                Button optionButton = new()
                {
                    Content = question.Options[i],
                    Height = 55,
                    Margin = new Thickness(0, 5, 0, 5),
                    Padding = new Thickness(12),
                    Background = Brushes.White,
                    Foreground = navy,
                    BorderBrush = navy,
                    BorderThickness = new Thickness(1),
                    FontSize = 14,
                    HorizontalContentAlignment = HorizontalAlignment.Left,
                    Cursor = System.Windows.Input.Cursors.Hand,
                    Tag = i
                };

                optionButton.Click += (sender, e) =>
                {
                    CheckAnswer(selectedAnswer);
                };

                optionsPanel.Children.Add(optionButton);
            }
        }

        private void CheckAnswer(int selectedAnswer)
        {
            if (answered)
                return;

            answered = true;

            QuizQuestion question = questions[currentQuestion];

            bool correct = selectedAnswer == question.CorrectAnswer;

            if (correct)
            {
                score++;

                feedbackText.Text =
                    "Correct! Well done!\n\n" + question.Explanation;

                feedbackText.Foreground =
                    new SolidColorBrush(Color.FromRgb(25, 125, 65));
            }
            else
            {
                feedbackText.Text =
                    "Incorrect. The correct answer is: " +
                    question.Options[question.CorrectAnswer] +
                    "\n\n" + question.Explanation;

                feedbackText.Foreground =
                    new SolidColorBrush(Color.FromRgb(180, 55, 45));
            }

            scoreText.Text = $"Score: {score}/{questions.Count}";

            foreach (Button button in optionsPanel.Children)
            {
                button.IsEnabled = false;

                int optionIndex = (int)button.Tag;

                if (optionIndex == question.CorrectAnswer)
                {
                    button.Background =
                        new SolidColorBrush(Color.FromRgb(205, 240, 210));
                }
                else if (optionIndex == selectedAnswer && !correct)
                {
                    button.Background =
                        new SolidColorBrush(Color.FromRgb(255, 215, 210));
                }
            }

            nextButton.IsEnabled = true;
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (!answered)
                return;

            currentQuestion++;

            if (currentQuestion < questions.Count)
            {
                ShowQuestion();
            }
            else
            {
                ShowResults();
            }
        }

        private void ShowResults()
        {
            optionsPanel.Children.Clear();

            questionNumberText.Text = "Quiz Completed!";

            questionText.Text =
                $"You scored {score} out of {questions.Count}.";

            string message;

            double percentage = (double)score / questions.Count * 100;

            if (percentage >= 80)
            {
                message = "Excellent work! You have a strong understanding of cybersecurity.";
            }
            else if (percentage >= 50)
            {
                message = "Good effort! Keep learning and improving your cybersecurity knowledge.";
            }
            else
            {
                message = "Keep practising! Learning about cybersecurity will help you stay safer online.";
            }

            feedbackText.Text =
                $"Your result: {percentage:0}%\n\n{message}";

            feedbackText.Foreground = navy;

            scoreText.Text = $"Final Score: {score}/{questions.Count}";

            nextButton.Content = "Restart Quiz";
            nextButton.IsEnabled = true;

            nextButton.Click -= NextButton_Click;
            nextButton.Click += RestartQuiz_Click;
        }

        private void RestartQuiz_Click(object sender, RoutedEventArgs e)
        {
            currentQuestion = 0;
            score = 0;
            answered = false;

            nextButton.Click -= RestartQuiz_Click;
            nextButton.Click += NextButton_Click;

            ShowQuestion();
        }
    }
}
